-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create table for storing homescreen element positions and sizes
CREATE TABLE public.homescreen_layout (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  screen_id TEXT NOT NULL DEFAULT 'default',
  element_id TEXT NOT NULL,
  position_x DOUBLE PRECISION NOT NULL,
  position_y DOUBLE PRECISION NOT NULL,
  width DOUBLE PRECISION NOT NULL,
  height DOUBLE PRECISION NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(screen_id, element_id)
);

-- Enable Row Level Security
ALTER TABLE public.homescreen_layout ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (no auth required)
CREATE POLICY "Allow public read access" 
ON public.homescreen_layout 
FOR SELECT 
USING (true);

CREATE POLICY "Allow public insert access" 
ON public.homescreen_layout 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow public update access" 
ON public.homescreen_layout 
FOR UPDATE 
USING (true);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_homescreen_layout_updated_at
BEFORE UPDATE ON public.homescreen_layout
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();