-- Create vfd_settings table for storing VFD configuration
CREATE TABLE public.vfd_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tag_name TEXT NOT NULL DEFAULT 'VFD-001',
  description TEXT DEFAULT 'Variable Frequency Drive',
  unit TEXT DEFAULT 'U-505',
  engineering_units TEXT DEFAULT 'Hz',
  transparent_background BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.vfd_settings ENABLE ROW LEVEL SECURITY;

-- Public access policies (no auth required for this settings table)
CREATE POLICY "Allow public read access" ON public.vfd_settings FOR SELECT USING (true);
CREATE POLICY "Allow public insert access" ON public.vfd_settings FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update access" ON public.vfd_settings FOR UPDATE USING (true);