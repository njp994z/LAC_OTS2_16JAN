ALTER TABLE homescreen_layout 
ADD COLUMN rotation INTEGER DEFAULT 0;