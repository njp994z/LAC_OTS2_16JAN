import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ControllerSyncProvider } from "@/contexts/ControllerSyncContext";
import { ControllerConfigProvider } from "@/contexts/ControllerConfigContext";
import { CompressorProvider } from "@/contexts/CompressorContext";
import Landing from "./pages/Landing";
import ControllerFaceplates from "./pages/ControllerFaceplates";
import TemperatureControllerFaceplates from "./pages/TemperatureControllerFaceplates";
import LevelControllerFaceplate from "./pages/LevelControllerFaceplate";
import ConcentrationControllerFaceplate from "./pages/ConcentrationControllerFaceplate";
import FlowControllerFaceplate from "./pages/FlowControllerFaceplate";
import SulfurFlowControllerFaceplate from "./pages/SulfurFlowControllerFaceplate";
import SulfurFlowControllerFaceplateMain from "./pages/SulfurFlowControllerFaceplateMain";
import MainCompressorHandControllerFaceplate from "./pages/MainCompressorHandControllerFaceplate";
import MainCompressorHandControllerFaceplateMain from "./pages/MainCompressorHandControllerFaceplateMain";
import HandController4030Faceplate3A from "./pages/HandController4030Faceplate3A";
import HandController4030Faceplate3B from "./pages/HandController4030Faceplate3B";
import HandController4030Faceplate3C from "./pages/HandController4030Faceplate3C";
import HandController4030Faceplate3D from "./pages/HandController4030Faceplate3D";
import HandController4030Faceplate3E from "./pages/HandController4030Faceplate3E";
import HandController4030Faceplate3F from "./pages/HandController4030Faceplate3F";
import JugValveHandControllerFaceplate from "./pages/JugValveHandControllerFaceplate";
import JugValveHandControllerFaceplateMain from "./pages/JugValveHandControllerFaceplateMain";
import HandController4282Faceplate3A from "./pages/HandController4282Faceplate3A";
import HandController4282Faceplate3B from "./pages/HandController4282Faceplate3B";
import HandController4282Faceplate3C from "./pages/HandController4282Faceplate3C";
import HandController4282Faceplate3D from "./pages/HandController4282Faceplate3D";
import HandController4282Faceplate3E from "./pages/HandController4282Faceplate3E";
import HandController4282Faceplate3F from "./pages/HandController4282Faceplate3F";
import WHBOutletHandControllerFaceplate from "./pages/WHBOutletHandControllerFaceplate";
import WHBOutletHandControllerFaceplateMain from "./pages/WHBOutletHandControllerFaceplateMain";
import HandController4283Faceplate3A from "./pages/HandController4283Faceplate3A";
import HandController4283Faceplate3B from "./pages/HandController4283Faceplate3B";
import HandController4283Faceplate3C from "./pages/HandController4283Faceplate3C";
import HandController4283Faceplate3D from "./pages/HandController4283Faceplate3D";
import HandController4283Faceplate3E from "./pages/HandController4283Faceplate3E";
import HandController4283Faceplate3F from "./pages/HandController4283Faceplate3F";
import HandIndicatedControllerFaceplate from "./pages/HandIndicatedControllerFaceplate";
import ControllerFaceplate from "./pages/ControllerFaceplate";
import SecondaryControllerFaceplate from "./pages/SecondaryControllerFaceplate";
import SensorFaceplate from "./pages/SensorFaceplate";
import TemperatureSensorsPage from "./pages/TemperatureSensorsPage";
import TempSensorDetail from "./pages/TempSensorDetail";
import PressureSensorsPage from "./pages/PressureSensorsPage";
import PressureSensorDetail from "./pages/PressureSensorDetail";
import LevelSensorsPage from "./pages/LevelSensorsPage";
import LevelSensorDetail from "./pages/LevelSensorDetail";
import PositionSensorsPage from "./pages/PositionSensorsPage";
import PositionSensorDetail from "./pages/PositionSensorDetail";
import ValveFaceplate from "./pages/ValveFaceplate";
import ValveTypeDetail from "./pages/ValveTypeDetail";
import FlowControlValveDetail from "./pages/FlowControlValveDetail";
import FlowControlValve3E from "./pages/FlowControlValve3E";
import TempControlValveDetail from "./pages/TempControlValveDetail";
import HandControlValveDetail from "./pages/HandControlValveDetail";
import JugValveDetail from "./pages/JugValveDetail";
import JugValve3E from "./pages/JugValve3E";
import JugValvePositionerDetail from "./pages/JugValvePositionerDetail";
import JugValvePositioner3E from "./pages/JugValvePositioner3E";
import AlarmFaceplate from "./pages/AlarmFaceplate";
import EquipmentFaceplates from "./pages/EquipmentFaceplates";
import CompressorFaceplate from "./pages/CompressorFaceplate";
import Faceplate3A from "./pages/Faceplate3A";
import Faceplate3B from "./pages/Faceplate3B";
import Faceplate3C from "./pages/Faceplate3C";
import Faceplate3D from "./pages/Faceplate3D";
import Faceplate3E from "./pages/Faceplate3E";
import Faceplate3F from "./pages/Faceplate3F";
import VFDSettings from "./pages/VFDSettings";
import VFDHistory from "./pages/VFDHistory";
import VFDTrends from "./pages/VFDTrends";
import VFDLinks from "./pages/VFDLinks";
import VFDCompare from "./pages/VFDCompare";
import VFDAlarms from "./pages/VFDAlarms";
import HomeScreen from "./pages/HomeScreen";
import TempSensor5821Landing from "./pages/TempSensor5821Landing";
import TempSensor5821Main from "./pages/TempSensor5821Main";
import TempSensor5821Faceplate3A from "./pages/TempSensor5821Faceplate3A";
import TempSensor5821Faceplate3B from "./pages/TempSensor5821Faceplate3B";
import TempSensor5821Faceplate3C from "./pages/TempSensor5821Faceplate3C";
import TempSensor5821Faceplate3D from "./pages/TempSensor5821Faceplate3D";
import TempSensor5821Faceplate3E from "./pages/TempSensor5821Faceplate3E";
import TempSensor5821Faceplate3F from "./pages/TempSensor5821Faceplate3F";
import TempSensor4200ALanding from "./pages/TempSensor4200ALanding";
import TempSensor4200AMain from "./pages/TempSensor4200AMain";
import TempSensor4200AFaceplate3A from "./pages/TempSensor4200AFaceplate3A";
import TempSensor4200AFaceplate3B from "./pages/TempSensor4200AFaceplate3B";
import TempSensor4200AFaceplate3C from "./pages/TempSensor4200AFaceplate3C";
import TempSensor4200AFaceplate3D from "./pages/TempSensor4200AFaceplate3D";
import TempSensor4200AFaceplate3E from "./pages/TempSensor4200AFaceplate3E";
import TempSensor4200AFaceplate3F from "./pages/TempSensor4200AFaceplate3F";
import TempSensor4200BLanding from "./pages/TempSensor4200BLanding";
import TempSensor4200BMain from "./pages/TempSensor4200BMain";
import TempSensor4200BFaceplate3A from "./pages/TempSensor4200BFaceplate3A";
import TempSensor4200BFaceplate3B from "./pages/TempSensor4200BFaceplate3B";
import TempSensor4200BFaceplate3C from "./pages/TempSensor4200BFaceplate3C";
import TempSensor4200BFaceplate3D from "./pages/TempSensor4200BFaceplate3D";
import TempSensor4200BFaceplate3E from "./pages/TempSensor4200BFaceplate3E";
import TempSensor4200BFaceplate3F from "./pages/TempSensor4200BFaceplate3F";
import TempSensor4200CLanding from "./pages/TempSensor4200CLanding";
import TempSensor4200CMain from "./pages/TempSensor4200CMain";
import TempSensor4200CFaceplate3A from "./pages/TempSensor4200CFaceplate3A";
import TempSensor4200CFaceplate3B from "./pages/TempSensor4200CFaceplate3B";
import TempSensor4200CFaceplate3C from "./pages/TempSensor4200CFaceplate3C";
import TempSensor4200CFaceplate3D from "./pages/TempSensor4200CFaceplate3D";

import TempSensor4200CFaceplate3F from "./pages/TempSensor4200CFaceplate3F";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <ControllerSyncProvider>
        <ControllerConfigProvider>
          <CompressorProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Routes>
                <Route path="/" element={<Landing />} />
                <Route path="/controller-faceplates" element={<ControllerFaceplates />} />
                <Route path="/temperature-controller" element={<TemperatureControllerFaceplates />} />
                <Route path="/level-controller" element={<LevelControllerFaceplate />} />
                <Route path="/concentration-controller" element={<ConcentrationControllerFaceplate />} />
                <Route path="/flow-controller" element={<FlowControllerFaceplate />} />
                <Route path="/sulfur-flow-controller" element={<SulfurFlowControllerFaceplate />} />
                <Route path="/sulfur-flow-controller-main" element={<SulfurFlowControllerFaceplateMain />} />
                <Route path="/hand-controller-4030" element={<MainCompressorHandControllerFaceplate />} />
                <Route path="/hand-controller-4030-main" element={<MainCompressorHandControllerFaceplateMain />} />
                <Route path="/hand-controller-4030-faceplate-3a" element={<HandController4030Faceplate3A />} />
                <Route path="/hand-controller-4030-faceplate-3b" element={<HandController4030Faceplate3B />} />
                <Route path="/hand-controller-4030-faceplate-3c" element={<HandController4030Faceplate3C />} />
                <Route path="/hand-controller-4030-faceplate-3d" element={<HandController4030Faceplate3D />} />
                <Route path="/hand-controller-4030-faceplate-3e" element={<HandController4030Faceplate3E />} />
                <Route path="/hand-controller-4030-faceplate-3f" element={<HandController4030Faceplate3F />} />
                <Route path="/hand-controller-4282-jug" element={<JugValveHandControllerFaceplate />} />
                <Route path="/hand-controller-4282-main" element={<JugValveHandControllerFaceplateMain />} />
                <Route path="/hand-controller-4282-faceplate-3a" element={<HandController4282Faceplate3A />} />
                <Route path="/hand-controller-4282-faceplate-3b" element={<HandController4282Faceplate3B />} />
                <Route path="/hand-controller-4282-faceplate-3c" element={<HandController4282Faceplate3C />} />
                <Route path="/hand-controller-4282-faceplate-3d" element={<HandController4282Faceplate3D />} />
                <Route path="/hand-controller-4282-faceplate-3e" element={<HandController4282Faceplate3E />} />
                <Route path="/hand-controller-4282-faceplate-3f" element={<HandController4282Faceplate3F />} />
                <Route path="/hand-controller-4283-whb" element={<WHBOutletHandControllerFaceplate />} />
                <Route path="/hand-controller-4283-main" element={<WHBOutletHandControllerFaceplateMain />} />
                <Route path="/hand-controller-4283-faceplate-3a" element={<HandController4283Faceplate3A />} />
                <Route path="/hand-controller-4283-faceplate-3b" element={<HandController4283Faceplate3B />} />
                <Route path="/hand-controller-4283-faceplate-3c" element={<HandController4283Faceplate3C />} />
                <Route path="/hand-controller-4283-faceplate-3d" element={<HandController4283Faceplate3D />} />
                <Route path="/hand-controller-4283-faceplate-3e" element={<HandController4283Faceplate3E />} />
                <Route path="/hand-controller-4283-faceplate-3f" element={<HandController4283Faceplate3F />} />
                <Route path="/hand-indicated-controller" element={<HandIndicatedControllerFaceplate />} />
                <Route path="/controller" element={<ControllerFaceplate />} />
                <Route path="/controller-secondary" element={<SecondaryControllerFaceplate />} />
                <Route path="/sensor" element={<SensorFaceplate />} />
                <Route path="/temperature-sensors" element={<TemperatureSensorsPage />} />
                <Route path="/temp-sensor/1520-TI-5821" element={<TempSensor5821Landing />} />
                <Route path="/temp-sensor-5821-main" element={<TempSensor5821Main />} />
                <Route path="/temp-sensor-5821-faceplate-3a" element={<TempSensor5821Faceplate3A />} />
                <Route path="/temp-sensor-5821-faceplate-3b" element={<TempSensor5821Faceplate3B />} />
                <Route path="/temp-sensor-5821-faceplate-3c" element={<TempSensor5821Faceplate3C />} />
                <Route path="/temp-sensor-5821-faceplate-3d" element={<TempSensor5821Faceplate3D />} />
                <Route path="/temp-sensor-5821-faceplate-3e" element={<TempSensor5821Faceplate3E />} />
                <Route path="/temp-sensor-5821-faceplate-3f" element={<TempSensor5821Faceplate3F />} />
                <Route path="/temp-sensor/1540-TI-4200A" element={<TempSensor4200ALanding />} />
                <Route path="/temp-sensor-4200a-main" element={<TempSensor4200AMain />} />
                <Route path="/temp-sensor-4200a-faceplate-3a" element={<TempSensor4200AFaceplate3A />} />
                <Route path="/temp-sensor-4200a-faceplate-3b" element={<TempSensor4200AFaceplate3B />} />
                <Route path="/temp-sensor-4200a-faceplate-3c" element={<TempSensor4200AFaceplate3C />} />
                <Route path="/temp-sensor-4200a-faceplate-3d" element={<TempSensor4200AFaceplate3D />} />
                <Route path="/temp-sensor-4200a-faceplate-3e" element={<TempSensor4200AFaceplate3E />} />
                <Route path="/temp-sensor-4200a-faceplate-3f" element={<TempSensor4200AFaceplate3F />} />
                <Route path="/temp-sensor/1540-TI-4200B" element={<TempSensor4200BLanding />} />
                <Route path="/temp-sensor-4200b-main" element={<TempSensor4200BMain />} />
                <Route path="/temp-sensor-4200b-faceplate-3a" element={<TempSensor4200BFaceplate3A />} />
                <Route path="/temp-sensor-4200b-faceplate-3b" element={<TempSensor4200BFaceplate3B />} />
                <Route path="/temp-sensor-4200b-faceplate-3c" element={<TempSensor4200BFaceplate3C />} />
                <Route path="/temp-sensor-4200b-faceplate-3d" element={<TempSensor4200BFaceplate3D />} />
                <Route path="/temp-sensor-4200b-faceplate-3e" element={<TempSensor4200BFaceplate3E />} />
                <Route path="/temp-sensor-4200b-faceplate-3f" element={<TempSensor4200BFaceplate3F />} />
                <Route path="/temp-sensor/1540-TI-4200C" element={<TempSensor4200CLanding />} />
                <Route path="/temp-sensor-4200c-main" element={<TempSensor4200CMain />} />
                <Route path="/temp-sensor-4200c-faceplate-3a" element={<TempSensor4200CFaceplate3A />} />
                <Route path="/temp-sensor-4200c-faceplate-3b" element={<TempSensor4200CFaceplate3B />} />
                <Route path="/temp-sensor-4200c-faceplate-3c" element={<TempSensor4200CFaceplate3C />} />
                <Route path="/temp-sensor-4200c-faceplate-3d" element={<TempSensor4200CFaceplate3D />} />
                
                <Route path="/temp-sensor-4200c-faceplate-3f" element={<TempSensor4200CFaceplate3F />} />
                <Route path="/temp-sensor/:sensorId" element={<TempSensorDetail />} />
                <Route path="/pressure-sensors" element={<PressureSensorsPage />} />
                <Route path="/pressure-sensor/:sensorId" element={<PressureSensorDetail />} />
                <Route path="/level-sensors" element={<LevelSensorsPage />} />
                <Route path="/level-sensor/:sensorId" element={<LevelSensorDetail />} />
                <Route path="/position-sensors" element={<PositionSensorsPage />} />
                <Route path="/position-sensor/:sensorId" element={<PositionSensorDetail />} />
                <Route path="/valve" element={<ValveFaceplate />} />
                <Route path="/valve/:valveType" element={<ValveTypeDetail />} />
                <Route path="/valve/flow-control/:valveId" element={<FlowControlValveDetail />} />
                <Route path="/valve/flow-control/:valveId/3e" element={<FlowControlValve3E />} />
                <Route path="/valve/temperature-control/:valveId" element={<TempControlValveDetail />} />
                <Route path="/valve/hand-control/:valveId" element={<HandControlValveDetail />} />
                <Route path="/jug-valve" element={<JugValveDetail />} />
                <Route path="/jug-valve/3e" element={<JugValve3E />} />
                <Route path="/jug-valve-positioner" element={<JugValvePositionerDetail />} />
                <Route path="/jug-valve-positioner/3e" element={<JugValvePositioner3E />} />
                <Route path="/alarm" element={<AlarmFaceplate />} />
                <Route path="/equipment-faceplates" element={<EquipmentFaceplates />} />
                <Route path="/compressor-faceplate" element={<CompressorFaceplate />} />
                <Route path="/faceplate-3a/:controllerId?" element={<Faceplate3A />} />
                <Route path="/faceplate-3b/:controllerId?" element={<Faceplate3B />} />
                <Route path="/faceplate-3c/:controllerId?" element={<Faceplate3C />} />
                <Route path="/faceplate-3d/:controllerId?" element={<Faceplate3D />} />
                <Route path="/faceplate-3e/:controllerId?" element={<Faceplate3E />} />
                <Route path="/faceplate-3f/:controllerId?" element={<Faceplate3F />} />
                <Route path="/vfd-settings" element={<VFDSettings />} />
                <Route path="/vfd-history" element={<VFDHistory />} />
                <Route path="/vfd-trends" element={<VFDTrends />} />
                <Route path="/vfd-links" element={<VFDLinks />} />
                <Route path="/vfd-compare" element={<VFDCompare />} />
                <Route path="/vfd-alarms" element={<VFDAlarms />} />
                <Route path="/home-screen" element={<HomeScreen />} />
                {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </CompressorProvider>
        </ControllerConfigProvider>
      </ControllerSyncProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;